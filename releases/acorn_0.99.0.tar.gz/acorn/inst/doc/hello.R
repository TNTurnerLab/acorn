## ----setup, include=FALSE-----------------------------------------------------
#library(knitr)
#library(tools)
#names(vignetteEngine(package = 'knitr'))
#knitr::opts_chunk$set(echo = TRUE)

## ----chunkName, eval=FALSE----------------------------------------------------
#      hello(3)
#  
#  #you reference other functions as bio3d::read.pdb()

