## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
library('acorn')

## -----------------------------------------------------------------------------
lsf.str("package:acorn")

## -----------------------------------------------------------------------------
input <- readDNV(paste(path.package("acorn"),"/extdata/dnms_from_Ng_et_al_2022_Human_Mutation_paper.txt.gz",sep="")) 
head(input)
str(input)

## -----------------------------------------------------------------------------
ind <- extractIndividual(input, "HG01928")
head(ind)
nrow(ind)
table(ind[,1])

## -----------------------------------------------------------------------------
ind <- extractIndividual(input, c("HG01928", "HG03915"))
head(ind)
nrow(ind)
table(ind[,1])

## -----------------------------------------------------------------------------
snvs <- extractSNVs(input)
nrow(snvs)

## -----------------------------------------------------------------------------
indels <- extractINDELs(input)
nrow(indels)

## -----------------------------------------------------------------------------
mnvs <- extractMNVs(input)
nrow(mnvs)

## -----------------------------------------------------------------------------
calculateTiTvratio(input)

## -----------------------------------------------------------------------------
calculateDeletionInsertionratio(input)

## -----------------------------------------------------------------------------
dellengths <- calculateDeletionLengths(input)
head(dellengths)

## -----------------------------------------------------------------------------
inslengths <- calculateInsertionLengths(input)
head(inslengths)

## -----------------------------------------------------------------------------
aut <- extractAutosomes(input)
nrow(aut)
table(aut[,2])

## -----------------------------------------------------------------------------
X <- extractX(input)
nrow(X)
table(X[,2])

## -----------------------------------------------------------------------------
Y <- extractY(input)
nrow(Y)

## -----------------------------------------------------------------------------
counts <- countsPerIndividual(input)
head(counts)

## -----------------------------------------------------------------------------
input <- readDNV(paste(path.package("acorn"),"/extdata/dnms_from_Ng_et_al_2022_Human_Mutation_paper.txt.gz",sep="")) 


countExample <- read.delim(paste(path.package("acorn"),"/extdata/dnm_count_example.txt",sep=""))
parentExample <- read.delim(paste(path.package("acorn"),"/extdata/parental_age_example.txt",sep=""))

## -----------------------------------------------------------------------------
parents <- parentalAgeObject(countExample, parentExample)

## -----------------------------------------------------------------------------
parentalAge(parents)

## -----------------------------------------------------------------------------
fatherAge(parents)

## -----------------------------------------------------------------------------
motherAge(parents)

